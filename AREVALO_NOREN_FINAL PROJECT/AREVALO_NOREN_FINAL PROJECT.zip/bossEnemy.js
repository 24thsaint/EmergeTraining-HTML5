class BossEnemy {
    constructor() {

    }
}